# 注意事项：
* 页面的HTML代码必须是 `<!DOCTYPE html>` 开头
* 除IE6、7外，所有浏览器均支持

# 在线文档
[http://www.layui.com/doc/](http://www.layui.com/doc/)
